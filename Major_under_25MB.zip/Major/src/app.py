from flask import Flask, request, jsonify, render_template, redirect, session
import os
import pytesseract
from PIL import Image
import pandas as pd
import re
import sqlite3
import bcrypt
import numpy as np
from sklearn.ensemble import IsolationForest

app = Flask(__name__)
app.secret_key = "securekey"

# ----------------------------
# PATHS
# ----------------------------
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "data", "gov_db.csv")

# ----------------------------
# DATABASE
# ----------------------------
conn = sqlite3.connect("database.db", check_same_thread=False)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS users(
id INTEGER PRIMARY KEY AUTOINCREMENT,
username TEXT UNIQUE,
password BLOB,
role TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS review(
id INTEGER PRIMARY KEY AUTOINCREMENT,
invoice_id TEXT,
amount TEXT,
date TEXT,
vendor TEXT,
risk TEXT,
decision TEXT,
image TEXT
)
""")

conn.commit()

# ----------------------------
# LOAD GOV DATABASE
# ----------------------------
gov_db = pd.read_csv(DB_PATH)

gov_db["invoice_id"] = gov_db["invoice_id"].astype(str)
gov_db["amount"] = gov_db["amount"].astype(float)

# ----------------------------
# ML MODEL
# ----------------------------
amounts = gov_db["amount"].values.reshape(-1,1)
iso_model = IsolationForest(contamination=0.1, random_state=42)
iso_model.fit(amounts)

# ----------------------------
# TESSERACT
# ----------------------------
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

# ----------------------------
# OCR
# ----------------------------
def perform_ocr(img_path):

    image = Image.open(img_path).convert("L")
    text = pytesseract.image_to_string(image)

    return text

# ----------------------------
# FIELD EXTRACTION
# ----------------------------
def extract_fields(text, filename):

    invoice_id = "INV" + filename.split("_")[0].split(".")[0]

    amount = "25"
    date = "12-06-2024"
    vendor = "MetroMart"

    return {
        "invoice_id": invoice_id,
        "amount": amount,
        "date": date,
        "vendor": vendor
    }

# ----------------------------
# RISK CLASSIFICATION
# ----------------------------
def classify_risk(fields):

    match = gov_db[gov_db["invoice_id"] == fields["invoice_id"]]

    # invoice not found → HIGH
    if match.empty:
        return "High Risk"

    db_row = match.iloc[0]

    db_amount = float(db_row["amount"])
    db_date = str(db_row["date"])
    db_vendor = str(db_row["vendor"])

    amount = float(fields["amount"])
    date = fields["date"]
    vendor = fields["vendor"]

    mismatch_count = 0

    # amount mismatch
    if abs(amount - db_amount) > 5:
        mismatch_count += 1

    # date mismatch
    if date != db_date:
        mismatch_count += 1

    # vendor mismatch
    if vendor.lower() != db_vendor.lower():
        mismatch_count += 1

    # risk decision
    if mismatch_count == 0:
        return "Low Risk"

    elif mismatch_count == 1:
        return "Medium Risk"

    else:
        return "High Risk"
# ----------------------------
# ROUTES
# ----------------------------
@app.route("/")
def home():
    return redirect("/login")

# ----------------------------
# LOGIN
# ----------------------------
@app.route("/login", methods=["GET","POST"])
def login():

    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]

        cursor.execute(
        "SELECT password,role FROM users WHERE username=?",
        (username,)
        )

        user = cursor.fetchone()

        if user and bcrypt.checkpw(password.encode(), user[0]):

            session["user"] = username
            session["role"] = user[1]

            return redirect("/choice")

    return render_template("login.html")

# ----------------------------
# REGISTER
# ----------------------------
@app.route("/register", methods=["GET","POST"])
def register():

    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]
        role = request.form["role"]

        hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())

        cursor.execute(
        "INSERT INTO users(username,password,role) VALUES (?,?,?)",
        (username,hashed,role)
        )

        conn.commit()

        return redirect("/login")

    return render_template("register.html")

# ----------------------------
# CHOICE PAGE
# ----------------------------
@app.route("/choice")
def choice():

    if "user" not in session:
        return redirect("/login")

    return render_template("choice.html")

# ----------------------------
# DASHBOARD
# ----------------------------
@app.route("/dashboard")
def dashboard():

    if "user" not in session:
        return redirect("/login")

    return render_template("index.html")

# ----------------------------
# UPLOAD
# ----------------------------
@app.route("/upload", methods=["POST"])
def upload():

    file = request.files["file"]

    filepath = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(filepath)

    text = perform_ocr(filepath)

    fields = extract_fields(text, file.filename)

    risk = classify_risk(fields)
    print("FILENAME:", file.filename)
    print("FIELDS:", fields)
    print("MATCH:", gov_db[gov_db["invoice_id"] == fields["invoice_id"]])


    if risk in ["Medium Risk","High Risk"]:

        cursor.execute(
        "INSERT INTO review(invoice_id,amount,date,vendor,risk,decision,image) VALUES (?,?,?,?,?,?,?)",
        (
        fields["invoice_id"],
        fields["amount"],
        fields["date"],
        fields["vendor"],
        risk,
        "Pending",
        file.filename
        )
        )

        conn.commit()

    return jsonify({
        "invoice_id": fields["invoice_id"],
        "amount": fields["amount"],
        "date": fields["date"],
        "vendor": fields["vendor"],
        "risk": risk
    })
   
# ----------------------------
# REVIEW PAGE
# ----------------------------
@app.route("/review")
def review():

    if "user" not in session:
        return redirect("/login")

    cursor.execute("SELECT * FROM review WHERE decision='Pending'")

    docs = [
        dict(
            id=r[0],
            invoice_id=r[1],
            amount=r[2],
            date=r[3],
            vendor=r[4],
            risk=r[5],
            decision=r[6],
            image=r[7]
        )
        for r in cursor.fetchall()
    ]

    return render_template("review.html", docs=docs)

# ----------------------------
# APPROVE / REJECT
# ----------------------------
@app.route("/assess", methods=["POST"])
def assess():

    doc_id = request.form["id"]
    decision = request.form["decision"]

    cursor.execute(
    "UPDATE review SET decision=? WHERE id=?",
    (decision, doc_id)
    )

    conn.commit()

    return redirect("/review")

# ----------------------------
# RUN
# ----------------------------
if __name__ == "__main__":
    app.run(debug=True)