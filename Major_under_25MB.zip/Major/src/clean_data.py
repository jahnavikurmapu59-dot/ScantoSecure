import pandas as pd
import re

df = pd.read_csv("gov_db_generated.csv")

def clean_amount(x):
    if pd.isna(x):
        return "not noted"
    x = str(x)
    x = re.sub(r'[^\d.]', '', x)
    return x if x != "" else "not noted"

def clean_date(x):
    if pd.isna(x):
        return "not noted"
    x = str(x)
    match = re.search(r'\d{1,2}[/-]\d{1,2}[/-]\d{2,4}', x)
    return match.group() if match else "not noted"

def clean_vendor(x):
    if pd.isna(x):
        return "not noted"
    x = str(x)
    if len(x) > 40:
        return "not noted"
    return x.strip()

df['amount'] = df['amount'].apply(clean_amount)
df['date'] = df['date'].apply(clean_date)
df['vendor'] = df['vendor'].apply(clean_vendor)

df['risk_label'] = df.apply(
    lambda row: "low" if row['amount'] != "not noted" and row['date'] != "not noted" else "high",
    axis=1
)

df.to_csv("final_gov_db.csv", index=False)

print("✅ Final cleaned DB created!")