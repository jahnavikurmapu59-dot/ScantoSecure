import os
import pytesseract
import cv2
import re
import pandas as pd

# ✅ FIX 1: Correct Tesseract path (CHANGE if needed)
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

# ✅ FIX 2: Correct dataset path
dataset_path = "data/dataset"

data = []

# 🔍 Extract amount
def extract_amount(text):
    amounts = re.findall(r'₹?\s?\d+[.,]?\d*', text)
    return amounts[-1] if amounts else "not noted"

# 🔍 Extract date
def extract_date(text):
    dates = re.findall(r'\d{1,2}[/-]\d{1,2}[/-]\d{2,4}', text)
    return dates[0] if dates else "not noted"

# 🔍 Extract vendor (top lines)
def extract_vendor(text):
    lines = text.split('\n')
    for line in lines[:5]:
        clean = line.strip()
        if len(clean) > 3:
            return clean
    return "not noted"

# 🚀 Main loop
for root, dirs, files in os.walk(dataset_path):
    for file in files:
        if file.lower().endswith(('.png', '.jpg', '.jpeg')):

            print("Processing:", file)  # ✅ Debug print

            path = os.path.join(root, file)

            img = cv2.imread(path)

            # ⚠️ Handle image read failure
            if img is None:
                print("❌ Failed to read:", path)
                continue

            try:
                text = pytesseract.image_to_string(img)
            except:
                print("❌ OCR failed for:", file)
                continue

            amount = extract_amount(text)
            date = extract_date(text)
            vendor = extract_vendor(text)

            data.append({
                "filename": file,
                "amount": amount,
                "date": date,
                "vendor": vendor
            })

# 📊 Save CSV
df = pd.DataFrame(data)

if df.empty:
    print("❌ No data extracted! Check dataset path.")
else:
    df.to_csv("gov_db_generated.csv", index=False)
    print("✅ CSV created successfully with", len(df), "records!")