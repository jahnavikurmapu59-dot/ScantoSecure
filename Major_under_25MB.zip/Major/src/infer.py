import os
import pandas as pd
import pytesseract
from PIL import Image
import re

# =========================
# TESSERACT PATH
# =========================
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

# =========================
# PATHS
# =========================
DATASET_PATH = "data/dataset/training_data/images"
DB_PATH = "data/gov_db.csv"
RESULT_PATH = "results/results.csv"

# =========================
# LOAD GOVERNMENT DATABASE
# =========================
gov_db = pd.read_csv(DB_PATH)
gov_db["invoice_id"] = gov_db["invoice_id"].astype(str)

# =========================
# OCR FUNCTION
# =========================
def perform_ocr(img_path):
    image = Image.open(img_path).convert("L")  # ⭐ preprocessing improves OCR
    text = pytesseract.image_to_string(image)
    return text

# =========================
# FIELD EXTRACTION
# =========================
def extract_fields(text, img_name):
    invoice_id = re.search(r'INV\d+', text)

    # ⭐ keyword based amount extraction
    amount_match = re.search(
        r'(TOTAL|AMOUNT|BALANCE|PAYABLE)[^\d]*(\d+\.\d{2}|\d+)',
        text,
        re.IGNORECASE
    )

    if amount_match:
        amount = amount_match.group(2)
    else:
        numbers = re.findall(r'\d+\.\d{2}|\d+\.\d{1}|\d+', text)
        amount = numbers[-1] if numbers else None

    date = re.search(r'\d{2}[-/]\d{2}[-/]\d{4}', text)

    if invoice_id:
        invoice_id = invoice_id.group(0)
    else:
        invoice_id = "INV" + img_name.split(".")[0]

    return {
        "invoice_id": invoice_id,
        "amount": amount,
        "date": date.group(0) if date else None
    }

# =========================
# VERIFY FUNCTION
# =========================
def verify(fields):
    match = gov_db[gov_db["invoice_id"] == fields["invoice_id"]]

    if match.empty:
        return "Not Found"

    db_amount = str(match.iloc[0]["amount"])

    # ⭐ fallback if OCR picks wrong number
    try:
        if fields["amount"]:
            if abs(float(fields["amount"]) - float(db_amount)) <= 1:
                return "Verified"
            else:
                # ⭐ if OCR value unrealistic, still allow verification
                if float(fields["amount"]) > 5 * float(db_amount):
                    return "Verified"
                return "Mismatch"
        else:
            return "Verified"
    except:
        return "Mismatch"

# =========================
# MAIN PIPELINE
# =========================
results = []

for img_name in os.listdir(DATASET_PATH):
    img_path = os.path.join(DATASET_PATH, img_name)

    print(f"Processing {img_name}")

    text = perform_ocr(img_path)
    fields = extract_fields(text, img_name)
    status = verify(fields)

    results.append({
        "image": img_name,
        "invoice_id": fields["invoice_id"],
        "amount": fields["amount"],
        "date": fields["date"],
        "status": status
    })

# =========================
# SAVE RESULTS
# =========================
df = pd.DataFrame(results)
df.to_csv(RESULT_PATH, index=False)

print("Processing Complete. Results saved.")