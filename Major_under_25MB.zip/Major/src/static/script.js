<script>

document.getElementById("uploadForm").addEventListener("submit", function(e){

e.preventDefault()

let fileInput = document.getElementById("fileInput")

if(fileInput.files.length === 0){
alert("Please upload a document")
return
}

let formData = new FormData()
formData.append("file", fileInput.files[0])

fetch("/upload",{
method:"POST",
body:formData
})

.then(response => response.json())

.then(data => {

document.getElementById("result").innerHTML = `
<h3>Extracted Details</h3>

<p><b>Invoice:</b> ${data.invoice_id}</p>
<p><b>Amount:</b> ${data.amount}</p>
<p><b>Date:</b> ${data.date}</p>
<p><b>Vendor:</b> ${data.vendor}</p>

<h3>Risk Level: ${data.risk}</h3>
`
})

.catch(error=>{
console.log(error)
alert("Upload failed")
})

})

</script>